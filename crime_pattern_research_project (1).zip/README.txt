CRIME PATTERN ANALYSIS — OVERLEAF PROJECT

FILES
- main.tex: Overleaf-ready IEEE-style research paper.
- figures/: figures already referenced by main.tex.
- crime_analysis.py: reproducible Python implementation.
- synthetic_crime_data.csv: generated example dataset.
- results/: saved output tables and model output.
- requirements.txt: Python packages.

IMPORTANT ACADEMIC NOTE
This is an original synthesis and implementation based on the four papers you supplied, with citations to those sources. Do not present the source papers' findings as your own. The current experiment uses SYNTHETIC data, not real crime records. The metrics are illustrative, not evidence of real-world forecasting performance. Before submission, replace the author details, read and verify every section, and follow your institution's rules for AI assistance and citation.

OVERLEAF
1. Create a blank project at https://www.overleaf.com.
2. Upload main.tex and the entire figures folder (with the PNG files inside).
3. Select main.tex as the main document if needed.
4. Choose pdfLaTeX and click Recompile.
5. Edit the author, department, university, and email placeholders.

RUN THE PYTHON CODE
Install packages:
    pip install -r requirements.txt
Run:
    python crime_analysis.py
The script saves regenerated data, metrics, and figures under outputs/.
The figures bundled for Overleaf are a snapshot of the same deterministic synthetic experiment.
